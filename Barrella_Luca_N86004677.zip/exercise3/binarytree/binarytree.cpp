#include <iostream>
#include <utility>
#include "binarytree.hpp"

namespace lasd {

/* ************************************************************************** */
//! Node is not accessible from outside the class BinaryTree, right?

// // Constructor
// template <typename Data>
// BinaryTree<Data>::Node::Node(const Data& data) : data(data) {}

// BinaryTree

// Constructor

//Opertator == (Node)
template <typename Data>
bool BinaryTree<Data>::Node::operator==(const Node& node) const noexcept {
    if (data != node.data) {
        return false;
    }

    if (HasLeftChild() != node.HasLeftChild() || HasRightChild() != node.HasRightChild()) {
        return false;
    }

    if (HasLeftChild() && LeftChild() != node.LeftChild()) {
        return false;
    }

    if (HasRightChild() && RightChild() != node.RightChild()) {
        return false;
    }

    return true;
}

//Opertator != (Node)
template <typename Data>
bool BinaryTree<Data>::Node::operator!=(const Node& node) const noexcept {
    return !(*this == node);
}

// Opertator ==
template <typename Data>
bool BinaryTree<Data>::operator==(const BinaryTree<Data>& tree) const noexcept {
    if (size != tree.size) {
        return false;
    }

    if (root == nullptr && tree.root == nullptr) {
        return true;
    }

    if (root == nullptr || tree.root == nullptr) {
        return false;
    }

    return *root == *tree.root;
}

// Opertator !=
template <typename Data>
bool BinaryTree<Data>::operator!=(const BinaryTree<Data>& tree) const noexcept {
    return !(*this == tree);
}






/* ************************************************************************** */

}

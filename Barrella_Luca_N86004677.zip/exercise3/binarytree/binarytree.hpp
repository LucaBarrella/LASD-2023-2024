
#ifndef BINARYTREE_HPP
#define BINARYTREE_HPP

/* ************************************************************************** */

#include "../container/container.hpp"
#include "../container/mappable.hpp"

#include "../iterator/iterator.hpp"

#include "../stack/vec/stackvec.hpp"
// #include "../stack/lst/stacklst.hpp" 
#include "../queue/vec/queuevec.hpp"
// #include "../queue/lst/queuelst.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class BinaryTree : virtual public PreOrderTraversableContainer<Data>,
                  virtual public PostOrderTraversableContainer<Data>,
                  virtual public InOrderTraversableContainer<Data>,
                  virtual public BreadthTraversableContainer<Data> {
  // Must extend PreOrderTraversableContainer<Data>,
  //             PostOrderTraversableContainer<Data>,
  //             InOrderTraversableContainer<Data>,
  //             BreadthTraversableContainer<Data>

private:

  // ...

protected:

  // ...

public:

  struct Node {

  protected:

    // Comparison operators
    // type operator==(argument) specifiers; // Comparison of abstract types is possible, but is not visible.
    inline bool operator!=(const Node& node) const noexcept;
    // type operator!=(argument) specifiers; // Comparison of abstract types is possible, but is not visible.
    inline bool operator==(const Node& node) const noexcept;

  public:

    // friend class BinaryTree<Data>; //todo verificare se va bene!
    friend class BinaryTree<Data>;

    // Destructorr
    virtual ~Node() = default;

    // Copy assignment
    // type operator=(argument); // Copy assignment of abstract types is not possible.
    Node &operator=(const Node &node) = delete;

    // Move assignment
    // type operator=(argument); // Move assignment of abstract types is not possible.
    Node &operator=(Node &&node) noexcept = delete;

    /* ********************************************************************** */

    // Specific member functions

    // type Element() specifiers; // Immutable access to the element (concrete function should not throw exceptions)
    virtual const Data& Element() const noexcept = 0;

    // type IsLeaf() specifiers; // (concrete function should not throw exceptions)
    virtual bool IsLeaf() const noexcept = 0;

    // type HasLeftChild() specifiers; // (concrete function should not throw exceptions)
    virtual bool HasLeftChild() const noexcept = 0;

    // type HasRightChild() specifiers; // (concrete function should not throw exceptions)
    virtual bool HasRightChild() const noexcept = 0;

    // type LeftChild() specifiers; // (concrete function must throw std::out_of_range when not existent)
    virtual Node& LeftChild() const = 0;

    // type RightChild() specifiers; // (concrete function must throw std::out_of_range when not existent)
    virtual Node& RightChild() const = 0;

  };
  /* ************************************************************************ */

  // Destructor
  // ~BinaryTree() specifiers
  virtual ~BinaryTree() = default;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument); // Copy assignment of abstract types is not possible.
  BinaryTree& operator=(const BinaryTree& tree) = delete;

  // Move assignment
  // type operator=(argument); // Move assignment of abstract types is not possible.
  BinaryTree& operator=(BinaryTree&& tree) noexcept = delete;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers; // Comparison of abstract binary tree is possible.
  inline bool operator!=(const BinaryTree& tree) const noexcept;

  // type operator!=(argument) specifiers; // Comparison of abstract binary tree is possible.
  inline bool operator==(const BinaryTree& tree) const noexcept;

  /* ************************************************************************ */

  // Specific member functions

  // type Root() specifiers; // (concrete function must throw std::length_error when empty)
  virtual Node& Root() const = 0;

  /* ************************************************************************ */

  // Specific member function (inherited from TraversableContainer)

  // using typename TraversableContainer<Data>::TraverseFun;
  using typename TraversableContainer<Data>::TraverseFun;
  //! CONTROLLARE!!!

  // type Traverse(arguments) specifiers; // Override TraversableContainer member
  void Traverse(const TraverseFun function) const override;
  /* ************************************************************************ */

  // Specific member function (inherited from PreOrderTraversableContainer)

  // type PreOrderTraverse(arguments) specifiers; // Override PreOrderTraversableContainer member
  void PreOrderTraverse(const TraverseFun function) const override;

  /* ************************************************************************ */

  // Specific member function (inherited from PostOrderTraversableContainer)

  // type PostOrderTraverse(arguments) specifiers; // Override PostOrderTraversableContainer member
  void PostOrderTraverse(const TraverseFun function) const override;

  /* ************************************************************************ */

  // Specific member function (inherited from InOrderTraversableContainer)

  // type InOrderTraverse(arguments) specifiers; // Override InOrderTraversableContainer member
  void InOrderTraverse(const TraverseFun function) const override;

  /* ************************************************************************ */

  // Specific member function (inherited from BreadthTraversableContainer)

  //! type BreadthTraverse(arguments) specifiers; // Override BreadthTraversableContainer member
  void BreadthTraverse(const TraverseFun function) const override;


  //! virtual void BreadthTraverse(TraverseFun function, const Node& node) const;

protected:

  // Auxiliary functions, if necessary! //!CONTROLLARE!!!

  // Auxiliary member functions for PreOrderTraversableContainer
  virtual void PreOrderTraverse(const TraverseFun function, const Node& node) const;

  // Auxiliary member functions for PostOrderTraversableContainer
  virtual void PostOrderTraverse(const TraverseFun function, const Node& node) const;

  // Auxiliary member functions for InOrderTraversableContainer
  virtual void InOrderTraverse(TraverseFun function, const Node& node) const;

  // Auxiliary member functions for BreadthTraversableContainer
  virtual void BreadthTraverse(TraverseFun function, const Node& node) const;

};

/* ************************************************************************** */

template <typename Data>
class MutableBinaryTree : virtual public BinaryTree<Data>,
                          //! Serve? virtual public MappableContainer<Data>,
                          virtual public PreOrderMappableContainer<Data>,
                          virtual public PostOrderMappableContainer<Data>,
                          virtual public InOrderMappableContainer<Data>,
                          virtual public BreadthMappableContainer<Data>{
  // Must extend ClearableContainer,
  //             BinaryTree<Data>,
  //             PreOrderMappableContainer<Data>,
  //             PostOrderMappableContainer<Data>,
  //             InOrderMappableContainer<Data>,
  //             BreadthMappableContainer<Data>

private:

  // ...

protected:

  // ...

public:

  struct MutableNode : public BinaryTree<Data>::Node {
    // Must extend Node

    // friend class MutableBinaryTree<Data>;
    friend class MutableBinaryTree<Data>;

    /* ********************************************************************** */

    // Destructor
    // ~MutableNode() specifiers
    virtual ~MutableNode() = default;

    /* ********************************************************************** */

    // Copy assignment
    // type operator=(argument); // Copy assignment of abstract types is not possible.
    MutableNode& operator=(const MutableNode& node) = delete;

    // Move assignment
    // type operator=(argument); // Move assignment of abstract types is not possible.
    MutableNode& operator=(MutableNode&& node) noexcept = delete;

    /* ********************************************************************** */

    // Specific member functions
    //! IL prof ha messo using Node::Element; e Node::LeftChild; e Node::RightChild;

    // type Element() specifiers; // Mutable access to the element (concrete function should not throw exceptions)
    //* using Node::Element;
    virtual Data& Element() noexcept = 0;

    // type LeftChild() specifiers; // (concrete function must throw std::out_of_range when not existent)
    //* using Node::LeftChild;
    virtual MutableNode& LeftChild() = 0;

    // type RightChild() specifiers; // (concrete function must throw std::out_of_range when not existent)
    //* using Node::RightChild;
    virtual MutableNode& RightChild() = 0;

  };

  /* ************************************************************************ */

  // Destructor
  // ~MutableBinaryTree() specifiers
  virtual ~MutableBinaryTree() = default;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument); // Copy assignment of abstract types is not possible.
  MutableBinaryTree& operator=(const MutableBinaryTree& tree) = delete;

  // Move assignment
  // type operator=(argument); // Move assignment of abstract types is not possible.
  MutableBinaryTree& operator=(MutableBinaryTree&& tree) noexcept = delete;

  /* ************************************************************************ */

  // Specific member functions

  // type Root() specifiers; // (concrete function must throw std::length_error when empty)
  // virtual MutableNode& Root() = 0;

  //! IL prof ha letterlmente scritto questo:
  using BinaryTree<Data>::Root;
  virtual MutableNode& Root() = 0;

  /* ************************************************************************ */

  // Specific member function (inherited from MappableContainer)

  // using typename MappableContainer<Data>::MapFun;
  using typename MappableContainer<Data>::MapFun;

  // type Map(argument) specifiers; // Override MappableContainer member
  inline void Map(MapFun functionmap) override;

  /* ************************************************************************ */

  // Specific member function (inherited from PreOrderMappableContainer)

  // type PreOrderMap(argument) specifiers; // Override PreOrderMappableContainer member
  inline void PreOrderMap(MapFun functionmap) override;

  /* ************************************************************************ */

  // Specific member function (inherited from PostOrderMappableContainer)

  // type PostOrderMap(argument) specifiers; // Override PostOrderMappableContainer member
  inline void PostOrderMap(MapFun functionmap) override;

  /* ************************************************************************ */

  // Specific member function (inherited from InOrderMappableContainer)

  // type InOrderMap(arguments) specifiers; // Override InOrderMappableContainer member
  inline void InOrderMap(MapFun functionmap) override;

  /* ************************************************************************ */

  // Specific member function (inherited from BreadthMappableContainer)

  // type BreadthMap(arguments) specifiers; // Override BreadthMappableContainer member
  inline void BreadthMap(MapFun functionmap) override;

protected:

  // Auxiliary functions, if necessary!
  //! CONTROLLARE!!! Ma penso sia fatto bene.

  // Auxiliary member functions for PreOrderMappableContainer
  virtual void PreOrderMap(MapFun functionmap, MutableNode& node) const;

  // Auxiliary member functions for PostOrderMappableContainer
  virtual void PostOrderMap(MapFun functionmap, MutableNode& node) const;

  // Auxiliary member functions for InOrderMappableContainer
  virtual void InOrderMap(MapFun functionmap, MutableNode& node) const;

  // Auxiliary member functions for BreadthMappableContainer
  virtual void BreadthMap(MapFun functionmap, MutableNode& node) const;

};

/* ************************************************************************** */

template <typename Data>
class BTPreOrderIterator : public ForwardIterator<Data>,
                           public ResettableIterator<Data>{
  // Must extend ForwardIterator<Data>,
  //             ResettableIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTPreOrderIterator(argument) specifiers; // An iterator over a given binary tree
  BTPreOrderIterator (const BinaryTree<Data>& tree);
  

  /* ************************************************************************ */

  // Copy constructor
  // BTPreOrderIterator(argument) specifiers;
  BTPreOrderIterator(const BTPreOrderIterator& iterator);

  // Move constructor
  // BTPreOrderIterator(argument) specifiers;
  BTPreOrderIterator(BTPreOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTPreOrderIterator() specifiers;
  virtual ~BTPreOrderIterator();

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTPreOrderIterator& operator=(const BTPreOrderIterator& iterator);
  

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTPreOrderIterator& operator=(BTPreOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTPreOrderIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTPreOrderIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const; //! Should be overrided method?
  //!devi solo fare l’override nella succ: operatore* con una const_cast

  // type Terminated() specifiers; // (should not throw exceptions)
  virtual bool Terminated() const noexcept override;

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)

  // type operator++() specifiers; // (throw std::out_of_range when terminated)
  virtual BTPreOrderIterator& operator++() override;
 
  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)

  // type Reset() specifiers; // (should not throw exceptions)
  virtual void Reset() noexcept override;

};

/* ************************************************************************** */

template <typename Data>
class BTPreOrderMutableIterator : public MutableIterator<Data>,
                                  public BTPreOrderIterator<Data>{
  // Must extend MutableIterator<Data>,
  //             BTPreOrderIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTPreOrderMutableIterator(argument) specifiers; // An iterator over a given mutable binary tree
  explicit BTPreOrderMutableIterator (BinaryTree<Data>& tree) noexcept;
  
  /* ************************************************************************ */

  // Copy constructor
  // BTPreOrderMutableIterator(argument) specifiers;
  explicit BTPreOrderMutableIterator(const BTPreOrderIterator& iterator);

  // Move constructor
  // BTPreOrderMutableIterator(argument) specifiers;
  explicit BTPreOrderMutableIterator(BTPreOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTPreOrderMutableIterator() specifiers;
  virtual ~BTPreOrderMutableIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTPreOrderMutableIterator& operator=(const BTPreOrderMutableIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTPreOrderMutableIterator& operator=(BTPreOrderMutableIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTPreOrderMutableIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTPreOrderMutableIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;
};

/* ************************************************************************** */

template <typename Data>
class BTPostOrderIterator : public ForwardIterator<Data>,
                            public ResettableIterator<Data>{
  // Must extend ForwardIterator<Data>,
  //             ResettableIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTPostOrderIterator(argument) specifiers; // An iterator over a given binary tree
  explicit BTPostOrderIterator (const BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTPostOrderIterator(argument) specifiers;
  explicit BTPostOrderIterator(const BTPostOrderIterator& iterator);

  // Move constructor
  // BTPostOrderIterator(argument) specifiers;
  explicit BTPostOrderIterator(BTPostOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTPostOrderIterator() specifiers;
  // virtual ~BTPostOrderIterator() noexcept;
  virtual ~BTPostOrderIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTPostOrderIterator& operator=(const BTPostOrderIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTPostOrderIterator& operator=(BTPostOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTPostOrderIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTPostOrderIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

  // type Terminated() specifiers; // (should not throw exceptions)
  virtual bool Terminated() const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)

  // type operator++() specifiers; // (throw std::out_of_range when terminated)
  virtual BTPostOrderIterator& operator++();

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)

  // type Reset() specifiers; // (should not throw exceptions)
  virtual void Reset() noexcept;

/* ************************************************************************** */
  
};

template <typename Data>
class BTPostOrderMutableIterator : public MutableIterator<Data>,
                                   public BTPostOrderIterator<Data>{
  // Must extend MutableIterator<Data>,
  //             BTPostOrderIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTPostOrderMutableIterator(argument) specifiers; // An iterator over a given mutable binary tree
  explicit BTPostOrderMutableIterator (BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTPostOrderMutableIterator(argument) specifiers;
  explicit BTPostOrderMutableIterator(const BTPostOrderIterator& iterator);

  // Move constructor
  // BTPostOrderMutableIterator(argument) specifiers;
  explicit BTPostOrderMutableIterator(BTPostOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTPostOrderMutableIterator() specifiers;
  virtual ~BTPostOrderMutableIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTPostOrderMutableIterator& operator=(const BTPostOrderMutableIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTPostOrderMutableIterator& operator=(BTPostOrderMutableIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTPostOrderMutableIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTPostOrderMutableIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

};

/* ************************************************************************** */

template <typename Data>
class BTInOrderIterator : public ForwardIterator<Data>,
                          public ResettableIterator<Data>{
  // Must extend ForwardIterator<Data>,
  //             ResettableIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTInOrderIterator(argument) specifiers; // An iterator over a given binary tree
  explicit BTInOrderIterator (const BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTInOrderIterator(argument) specifiers;
  explicit BTInOrderIterator(const BTInOrderIterator& iterator);

  // Move constructor
  // BTInOrderIterator(argument) specifiers;
  explicit BTInOrderIterator(BTInOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTInOrderIterator() specifiers;
  virtual ~BTInOrderIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTInOrderIterator& operator=(const BTInOrderIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTInOrderIterator& operator=(BTInOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTInOrderIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTInOrderIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

  // type Terminated() specifiers; // (should not throw exceptions)
  virtual bool Terminated() const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)

  // type operator++() specifiers; // (throw std::out_of_range when terminated)
  virtual BTInOrderIterator& operator++();

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)

  // type Reset() specifiers; // (should not throw exceptions)
  virtual void Reset() noexcept;

};

/* ************************************************************************** */

template <typename Data>
class BTInOrderMutableIterator : public MutableIterator<Data>,
                                 public BTInOrderIterator<Data>{
  // Must extend MutableIterator<Data>,
  //             BTInOrderIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTInOrderMutableIterator(argument) specifiers; // An iterator over a given mutable binary tree
  explicit BTInOrderMutableIterator (BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTInOrderMutableIterator(argument) specifiers;
  explicit BTInOrderMutableIterator(const BTInOrderIterator& iterator);

  // Move constructor
  // BTInOrderMutableIterator(argument) specifiers;
  explicit BTInOrderMutableIterator(BTInOrderIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTInOrderMutableIterator() specifiers;
  virtual ~BTInOrderMutableIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTInOrderMutableIterator& operator=(const BTInOrderMutableIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTInOrderMutableIterator& operator=(BTInOrderMutableIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTInOrderMutableIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTInOrderMutableIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

};

/* ************************************************************************** */

template <typename Data>
class BTBreadthIterator : public ForwardIterator<Data>,
                          public ResettableIterator<Data>{
  // Must extend ForwardIterator<Data>,
  //             ResettableIterator<Data>

private:

  // ...

protected:

  // ...
  const typename BinaryTree<Data>::root = nullptr;
  QueueVec<BinaryTree<Data>::Node*> queue;

public:

  // Specific constructors
  // BTBreadthIterator(argument) specifiers; // An iterator over a given binary tree
  explicit BTBreadthIterator (const BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTBreadthIterator(argument) specifiers;
  explicit BTBreadthIterator(const BTBreadthIterator& iterator);

  // Move constructor
  // BTBreadthIterator(argument) specifiers;
  explicit BTBreadthIterator(BTBreadthIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTBreadthIterator() specifiers;
  virtual ~BTBreadthIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTBreadthIterator& operator=(const BTBreadthIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTBreadthIterator& operator=(BTBreadthIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTBreadthIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTBreadthIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

  // type Terminated() specifiers; // (should not throw exceptions)
  virtual bool Terminated() const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)

  // type operator++() specifiers; // (throw std::out_of_range when terminated)
  virtual BTBreadthIterator& operator++();

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)

  // type Reset() specifiers; // (should not throw exceptions)
  virtual void Reset() noexcept;

};

/* ************************************************************************** */

template <typename Data>
class BTBreadthMutableIterator : public MutableIterator<Data>,
                                 public BTBreadthIterator<Data>{
  // Must extend MutableIterator<Data>,
  //             BTBreadthIterator<Data>

private:

  // ...

protected:

  // ...

public:

  // Specific constructors
  // BTBreadthMutableIterator(argument) specifiers; // An iterator over a given mutable binary tree
  explicit BTBreadthMutableIterator (BinaryTree<Data>& tree) noexcept;

  /* ************************************************************************ */

  // Copy constructor
  // BTBreadthMutableIterator(argument) specifiers;
  explicit BTBreadthMutableIterator(const BTBreadthIterator& iterator);

  // Move constructor
  // BTBreadthMutableIterator(argument) specifiers;
  explicit BTBreadthMutableIterator(BTBreadthIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Destructor
  // ~BTBreadthMutableIterator() specifiers;
  virtual ~BTBreadthMutableIterator() noexcept;

  /* ************************************************************************ */

  // Copy assignment
  // type operator=(argument) specifiers;
  virtual BTBreadthMutableIterator& operator=(const BTBreadthMutableIterator& iterator);

  // Move assignment
  // type operator=(argument) specifiers;
  virtual BTBreadthMutableIterator& operator=(BTBreadthMutableIterator&& iterator) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  // type operator==(argument) specifiers;
  virtual bool operator==(const BTBreadthMutableIterator& iterator) const noexcept;

  // type operator!=(argument) specifiers;
  virtual bool operator!=(const BTBreadthMutableIterator& iterator) const noexcept;

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)

  // type operator*() specifiers; // (throw std::out_of_range when terminated)
  virtual Data& operator*() const;

};

/* ************************************************************************** */

}

#include "binarytree.cpp"

#endif


#ifndef EX2BTEST_HPP
#define EX2BTEST_HPP

/* ************************************************************************** */

void testSimpleExercise2B(unsigned int &, unsigned int &);

void testFullExercise2B(unsigned int &, unsigned int &);

/* ************************************************************************** */

#endif
